#pragma once
#include "ForwardList.h"

class List_Test {
public:
	void test();
private:
	void test1();
	void test2();
	void test3();
	void test4();
	void test5();
	void test6();
	void test7();
	void test8();
	void test9();
	void print_res(const char* test, bool res);
};