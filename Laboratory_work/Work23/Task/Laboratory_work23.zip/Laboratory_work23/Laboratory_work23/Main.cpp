#include "List_Test.h"
#include "ForwardList.h"

int main() {
	List_Test t;
	t.test();
	return 0;
}