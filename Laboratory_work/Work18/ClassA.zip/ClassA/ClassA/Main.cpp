#include"Pet.h"
#include"Dog.h"
#include"Cat.h"
#include"Hamster.h"
#include"Parrot.h"
#include"Bird.h"

int main() {
	Dog dog("dog", "dog");
	Cat cat("cat","Andrei");
	Hamster hamster("hamster", "hamster");
	Parrot myPrrot("parrot", "Vorobyshek");
	Bird myBird("bird", "Dimka");

	Pet* myPet = &myPrrot;
	std::cout << myPet->show() << std::endl;
	myPet->sound();
	myPet->type();

	std::cout << std::endl;

	Pet* myPet1 = &myBird;
	std::cout << myPet->show() << std::endl;
	myPet1->sound();
	myPet1->type();

	std::cout << std::endl;

	return 0;
}