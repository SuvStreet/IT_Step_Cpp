#include "Pet.h"

void Pet::setName(const std::string newname) {
	name = newname;
}

std::string Pet::show() const {
	return name;
}

std::string Pet::type() const {
	std::cout << animal << std::endl;
	return animal;
}